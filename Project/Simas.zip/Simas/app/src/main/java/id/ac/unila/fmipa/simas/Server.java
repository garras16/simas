package id.ac.unila.fmipa.simas;

public class Server {
    public static final String URL = "http://simasunila.000webhostapp.com/";
    // public static final String URL = "http://192.168.43.81/simas/login/";
}
